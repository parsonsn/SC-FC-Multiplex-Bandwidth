import numpy as np

def direct(sc, sc_bin, fc_bin):
    """
    Returns the weighted direct SC-FC bandwidths

    Parameters
    ----------
    sc : numpy.ndarray
        Weighted SC matrix
    sc_bin : numpy.ndarray
        Binarised SC matrix
    fc_bin : numpy.ndarray
        Binarised FC matrix

    Returns
    -------
    out : numpy.ndarray
        Weighted SC-FC direct bandwidth
    """
    return sc * sc_bin * fc_bin

def triangles(sc, sc_bin, fc_bin):
    """
    Returns the weighted triangle SC-FC bandwidths

    Parameters
    ----------
    sc : numpy.ndarray
        Weighted SC matrix
    sc_bin : numpy.ndarray
        Binarised SC matrix
    fc_bin : numpy.ndarray
        Binarised FC matrix

    Returns
    -------
    out : numpy.ndarray
        Weighted SC-FC triangles bandwidths
    """
    W = sc * sc_bin
    fn_inner = lambda i, j, k: min(W[i,k], W[k,j])
    return _measure(sc_bin, fc_bin, fn_inner)

def quads(sc, sc_bin, fc_bin, T=None):
    """
    Returns the weighted SC-FC quads bandwidths

    Parameters
    ----------
    sc : numpy.ndarray
        Weighted SC matrix
    sc_bin : numpy.ndarray
        Binarised SC matrix
    fc_bin : numpy.ndarray
        Binarised FC matrix
    method : str
        'max' : Return the maximum bandwidth of all paths between nodes
        'sum' : Return the sum of bandwidths for all paths between nodes
    T : numpy.ndarray
        Recycled weighted SC-FC triangles matrix to speed up computation

    Returns
    -------
    out : numpy.ndarray
        Weighted SC-FC quads bandwidths
    """
    if T is None:
        T = triangles(sc, sc_bin, fc_bin)

    W = sc * sc_bin
    fn_inner = lambda i, j, k: min(W[i,k], W[k,j])
    M = _k_loop(fn_inner, sc_bin)
    fn_inner = lambda i, j, k: min(M[i,k], W[k,j])
    return _measure(sc_bin, fc_bin, fn_inner) * (1 - (T > 0))


# Internal usage only

def _measure(sc_bin, fc_bin, fn_inner):
    # Returns the result of any bandwidth measure
    return fc_bin * (1 - sc_bin) * _k_loop(fn_inner, sc_bin)

def _k_loop(fn_inner, sc_bin):
    # Returns the 'max k in V' component of the formulas
    n = len(sc_bin)
    M = np.zeros((n,n))
    for i, j in zip(*np.triu_indices(n, 1)):
        val = _single_k_loop(fn_inner, i, j, sc_bin)
        M[i,j] = val
        M[j,i] = val
    return M

def _single_k_loop(fn_inner, i, j, sc_bin):
    # Returns a single 'min' component of the formulas
    fn_val = 0
    for k in range(len(sc_bin)):
        if sc_bin[k,j] != 0: # Remove condition if right side of fn_inner doesn't use W = sc * sc_bin
            fn_val = max(fn_val, fn_inner(i,j,k))
    return fn_val