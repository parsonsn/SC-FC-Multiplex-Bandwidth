# Multiplex Bandwidth
Used to analyse throughput in the human brain from structural and functional connectivity matrices.

## Requirements
Requires installation of:
* python 3
* numpy

## Importing
Create a new python script and import numpy and the contents of `sc_fc_multiplex_bandwidth.py`
```
import numpy as np
import sc_fc_multiplex_bandwidth as scfc
```

## Available methods

More information on parameters and examples for each method can be found with the `help` function in python 3 (e.g. `help(scfc.triangles)`)
* `direct`: Returns the SC-FC bandwidths between nodes from direct SC edges
* `triangles`: Returns the SC-FC bandwidths between nodes that require at least an SC 2-path
* `quads`: Returns the SC-FC bandwidths between nodes that require at least an SC 3-path

## Examples
```
import numpy as np
import sc_fc_multiplex_bandwidth as scfc

sc = np.array(
    [[ 0, 1, 2,14, 3, 4],
     [ 1, 0,15, 5,11,12],
     [ 2,15, 0, 6, 7, 8],
     [14, 5, 6, 0,10,13],
     [ 3,11, 7,10, 0, 9],
     [ 4,12, 8,13, 9, 0]])

sc_bin = sc >= 10

fc_bin = np.array(
    [[0,1,0,0,0,0],
     [1,0,1,1,0,0],
     [0,1,0,0,0,1],
     [0,1,0,0,1,0],
     [0,0,0,1,0,1],
     [0,0,1,0,1,0]])
```

### Direct
```
print(scfc.direct(sc, sc_bin, fc_bin))

[[ 0  0  0  0  0  0]
 [ 0  0 15  0  0  0]
 [ 0 15  0  0  0  0]
 [ 0  0  0  0 10  0]
 [ 0  0  0 10  0  0]
 [ 0  0  0  0  0  0]]
```

### Triangles
```
print(scfc.triangles(sc, sc_bin, fc_bin))

[[ 0  0  0  0  0  0]
 [ 0  0  0 12  0  0]
 [ 0  0  0  0  0 12]
 [ 0 12  0  0  0  0]
 [ 0  0  0  0  0 11]
 [ 0  0 12  0 11  0]]
```

### Quads
```
print(scfc.quads(sc, sc_bin, fc_bin))

[[ 0 12  0  0  0  0]
 [12  0  0  0  0  0]
 [ 0  0  0  0  0  0]
 [ 0  0  0  0  0  0]
 [ 0  0  0  0  0  0]
 [ 0  0  0  0  0  0]]
```